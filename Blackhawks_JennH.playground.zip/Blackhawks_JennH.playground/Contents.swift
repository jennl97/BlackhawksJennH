//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var players: [[String:Any]] = [
    [
        "playersNumber": 24,
        "playersName": "Spencer Abbott",
        "playersAge": 28,
        "playersHeight": 69,
        "playersMonth": "April",
        "playersCountry": "Canada"],
    [
        "playersNumber": 15,
        "playersName": "Artem Anisimov",
        "playersAge": 28,
        "playersHeight": 76,
        "playersMonth": "May",
        "playersCountry": "Russia"
    ],
    [ "playersNumber": 37,
        "playersName": "Sam Carrick",
        "playersAge": 24,
        "playersHeight": 72,
        "playersMonth": "February",
        "playersCountry": "Canada"
    ],
    [
        "playersNumber": 11,
        "playersName": "Andrew Desjardins",
        "playersAge": 30,
        "playersHeight": 73,
        "playersMonth": "July",
        "playersCountry": "Canada"],
    [
        "playersNumber": 82,
        "playersName": "Alexandre Fortin",
        "playersAge": 19,
        "playersHeight": 72,
        "playersMonth": "February",
        "playersCountry": "Canada"],
    [
        "playersNumber": 38,
        "playersName": "Ryan Hartman",
        "playersAge": 22,
        "playersHeight": 72,
        "playersMonth": "September",
        "playersCountry": "USA"],
    [
        "playersNumber": 48,
        "playersName": "Vinnie Hinostroza",
        "playersAge": 22,
        "playersHeight": 69,
        "playersMonth": "April",
        "playersCountry": "USA"],
    [
        "playersNumber": 81,
        "playersName": "Marian Hossa",
        "playersAge": 37,
        "playersHeight": 73,
        "playersMonth": "January",
        "playersCountry": "Slovakia"],
    [
        "playersNumber": 88,
        "playersName": "Patrick Kane",
        "playersAge": 28,
        "playersHeight": 71,
        "playersMonth": "November",
        "playersCountry": "USA"],
    [
        "playersNumber": 16,
        "playersName": "Marcus Kruger",
        "playersAge": 26,
        "playersHeight": 72,
        "playersMonth": "May",
        "playersCountry": "Sweden"],
    [
        "playersNumber": 26,
        "playersName": "Pierre-Cedric Labrie",
        "playersAge": 30,
        "playersHeight": 75,
        "playersMonth": "December",
        "playersCountry": "Canada"],
    [
        "playersNumber": 53,
        "playersName": "Brandon Mashinter",
        "playersAge": 28,
        "playersHeight": 76,
        "playersMonth": "September",
        "playersCountry": "Canada"],
    [
        "playersNumber": 41,
        "playersName": "Mark McNeill",
        "playersAge": 23,
        "playersHeight": 74,
        "playersMonth": "February",
        "playersCountry": "Canada"],
    [
        "playersNumber": 64,
        "playersName": "Tyler Motte",
        "playersAge": 21,
        "playersHeight": 69,
        "playersMonth": "March",
        "playersCountry": "USA"
    ],
    [
        "playersNumber": 72,
        "playersName": "Artemi Panarin",
        "playersAge": 24,
        "playersHeight": 71,
        "playersMonth": "October",
        "playersCountry": "Russia"
    ],
    [
        "playersNumber": 14,
        "playersName": "Richard Panik",
        "playersAge": 25,
        "playersHeight": 73,
        "playersMonth": "February",
        "playersCountry": "Slovakia"
    ],
    [
        "playersNumber": 70,
        "playersName": "Dennis Rasmussen",
        "playersAge": 26,
        "playersHeight": 75,
        "playersMonth": "July",
        "playersCountry": "Sweden"
    ],
    [
        "playersNumber": 08,
        "playersName": "Nick Schmaltz",
        "playersAge": 20,
        "playersHeight": 72,
        "playersMonth": "February",
        "playersCountry": "USA"
    ],
    [
        "playersNumber": 19,
        "playersName": "Jonathan Toews",
        "playersAge": 28,
        "playersHeight": 74,
        "playersMonth": "April",
        "playersCountry": "Canada"
    ],
    [
        "playersNumber": 22,
        "playersName": "Jordan Tootoo",
        "playersAge": 33,
        "playersHeight": 74,
        "playersMonth": "February",
        "playersCountry": "Canada"
    ],
    [
        "playersNumber": 51,
        "playersName": "Brian Campbell",
        "playersAge": 37,
        "playersHeight": 70,
        "playersMonth": "May",
        "playersCountry": "Canada"
    ],
    [
        "playersNumber": 42,
        "playersName": "Gustav Forsling",
        "playersAge": 20,
        "playersHeight": 71,
        "playersMonth": "June",
        "playersCountry": "Sweden"
    ],
    [
        "playersNumber": 04,
        "playersName": "Niklas Hjalmarsson",
        "playersAge": 29,
        "playersHeight": 75,
        "playersMonth": "June",
        "playersCountry": "Sweden"
    ],
    [
        "playersNumber": 02,
        "playersName": "Duncan Keith",
        "playersAge": 33,
        "playersHeight": 73,
        "playersMonth": "July",
        "playersCountry": "Canada"
    ],
    [
        "playersNumber": 06,
        "playersName": "Michal Kempny",
        "playersAge": 26,
        "playersHeight": 72,
        "playersMonth": "July",
        "playersCountry": "Czechoslovakia"
    ],
    [
        "playersNumber": 32,
        "playersName": "Michal Rozsival",
        "playersAge": 38,
        "playersHeight": 73,
        "playersMonth": "September",
        "playersCountry": "Czechoslovakia"
    ],
    [
        "playersNumber": 47,
        "playersName": "Cameron Shilling",
        "playersAge": 28,
        "playersHeight": 75,
        "playersMonth": "October",
        "playersCountry": "USA"
    ],
    [
        "playersNumber": 47,
        "playersName": "Brent Seabrook",
        "playersAge": 31,
        "playersHeight": 75,
        "playersMonth": "April",
        "playersCountry": "Canada"
    ],
    [
        "playersNumber": 43,
        "playersName": "Viktor Svedberg",
        "playersAge": 25,
        "playersHeight": 80,
        "playersMonth": "May",
        "playersCountry": "Sweden"
    ],
    [
        "playersNumber": 57,
        "playersName": "Trevor van Riemsdyk",
        "playersAge": 25,
        "playersHeight": 74,
        "playersMonth": "July",
        "playersCountry": "USA"
    ],
    [
        "playersNumber": 50,
        "playersName": "Corey Crawford",
        "playersAge": 32,
        "playersHeight": 74,
        "playersMonth": "December",
        "playersCountry": "Canada"
    ],
    [
        "playersNumber": 33,
        "playersName": "Scott Darling",
        "playersAge": 28,
        "playersHeight": 78,
        "playersMonth": "December",
        "playersCountry": "USA"
    ],
    
    ]

func compareAge(first: [String:Any], second: [String:Any]) -> Bool {
    if let a = first["playersAge"] as? Int {
        if let b = second["playersAge"] as? Int {
            return a < b
        }
    }
    return false
}

players.sortInPlace(compareAge)

for (index, player) in players.enumerate() {
    if let playerName = player["playersName"] as? String {
        if let score = player["playersAge"] as? Int {
            print("\(index + 1). \(playerName) - \(score)")
            
        }
    }
 }

func compareCountry(first: [String:Any], second: [String:Any]) -> Bool {
    if let a = first["playersCountry"] as? String {
        if let b = second["playersCountry"] as? String {
            return a < b
        }
    }
    return false
}

players.sortInPlace(compareCountry)

for (index, player) in players.enumerate() {
    if let playerName = player["playersName"] as? String {
        if let score = player["playersCountry"] as? String {
            print("\(index + 1). \(playerName) - \(score)")
            
        }
    }
}

var totalAge = 0
    for (_,player) in players.enumerate(){
        totalAge += (player["playersAge"] as? Int)!

}
print("Average age = \(totalAge/players.count)")

var totalHeight = 0
for (_,player) in players.enumerate(){
    totalHeight += (player["playersHeight"] as? Int)!
    
}
print("Average height = \(totalHeight/players.count) inches.")


var months: [String] = []
for player in players{
    months.append((player["playersMonth"] as? String)!)
}

var frequency: [String:Int] = [:]
var uniqueMonths: [String] = []

for month in months {
    if let oldFr = frequency[month]{
        frequency[month] = oldFr + 1
    }else{
        uniqueMonths.append(month)
        frequency[month] = 1
    }
}

for month in uniqueMonths {
    print("\(month) \(frequency[month]!)")
}